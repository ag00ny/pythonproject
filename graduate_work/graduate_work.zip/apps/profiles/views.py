from django.shortcuts import render, redirect, get_object_or_404
from .forms import (
    UserRegistrationForm,
    UserLoginForm
)
from .models import (
    Profile,
    Basket,
    BasketItem
)
from apps.home.models import ShopItem
from django.contrib.auth import authenticate, login, logout


def register_view(request):
    if request.method == 'POST':
        form = UserRegistrationForm(data=request.POST)
        if form.is_valid():
            user = form.save()
            Profile.objects.create(user=user)
            return redirect('login')
        else:
            print(form.errors)
    else:

        form = UserRegistrationForm()
    context = {'form': form}
    return render(request, 'profiles/registration.html', context)


def login_view(request):
    if request.method == 'POST':
        form = UserLoginForm(data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('profile')
    else:
        form = UserLoginForm()
    context = {'form': form}

    return render(request, 'profiles/login.html', context)


def profile_view(request):
    return render(request, 'profiles/profile.html')


def get_or_create_basket(user):
    basket, created = Basket.objects.get_or_create(user=user)
    return basket


def basket_view(request):
    if request.user.is_authenticated:
        basket = get_or_create_basket(request.user)
        basket_items = BasketItem.objects.filter(basket=basket)
        context = {'items': basket_items}
        return render(request, 'profiles/basket.html', context)
    else:
        return redirect('login')


def add_to_basket(request, item_id):
    if request.user.is_authenticated:
        basket = get_or_create_basket(request.user)
        item = get_object_or_404(ShopItem, pk=item_id)
        basket_item, created = BasketItem.objects.get_or_create(basket=basket, item=item)
        if not created:
            basket_item.quantity += 1
        basket_item.save()
        return redirect('basket')
    else:
        return redirect('login')


def remove_from_basket(request, item_id):
    if request.user.is_authenticated:
        basket = get_or_create_basket(request.user)
        basket_item = get_object_or_404(BasketItem, basket=basket, item_id=item_id)
        basket_item.delete()
        return redirect('basket')
    else:
        return redirect('basket')


def logout_view(request):
    logout(request)
    return redirect('home')





