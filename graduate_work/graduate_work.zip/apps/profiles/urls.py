from django.urls import path
from .views import (
    register_view,
    login_view,
    profile_view,
    basket_view,
    add_to_basket,
    remove_from_basket,
    logout_view
)
urlpatterns = [
    path('register/', register_view, name='register'),
    path('login/', login_view, name='login'),
    path('profile/', profile_view, name='profile'),
    path('basket/', basket_view, name='basket'),
    path('basket/add/<int:item_id>/', add_to_basket, name='add_to_basket'),
    path('logout/', logout_view, name='logout'),
]