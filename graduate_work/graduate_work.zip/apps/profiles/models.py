from django.db import models
from django.contrib.auth.models import User
from apps.home.models import ShopItem


class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)


class Basket(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='basket')
    created_at = models.DateTimeField(auto_now_add=True)


class BasketItem(models.Model):
    basket = models.ForeignKey(Basket, on_delete=models.CASCADE, related_name='items')
    item = models.ForeignKey(ShopItem, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    quantity = models.PositiveIntegerField(default=1)
    class Meta:
        unique_together = ('basket', 'item')


